package com.example.studentcourseapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener {
    TextView fees,hours,totalfees,totalhours,message;
    RadioButton graduated,ungraduated;
    Spinner spin;
    CheckBox accomodation,medical;
    Button add;
    TextView welcome;
    String course[] = {"Java", "Swift", "IOS","Android","Database"};
    String afees[] = {"1300", "1500", "1350","1400","1000"};
    String ahours[] = {"6", "5", "5","7","4"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        welcome = findViewById(R.id.txtWelcome);
        welcome.setText("Welcome "+ Login.name.getText());
        fees = findViewById(R.id.txtFees);
        hours = findViewById(R.id.txtHours);
        totalfees = findViewById(R.id.txtTotalF);
        totalhours = findViewById(R.id.txtTotalH);
        message = findViewById(R.id.txtMessage);
        graduated = findViewById(R.id.rbGrad);
        ungraduated = findViewById(R.id.rbNotGrad);
        spin = findViewById(R.id.sp);
        accomodation = findViewById(R.id.cbAcco);
        medical = findViewById(R.id.cbMed);
        add = findViewById(R.id.btnAdd);
        add.setOnClickListener(this);
        spin.setOnItemSelectedListener(this);
        ArrayAdapter aa = new ArrayAdapter(this, android.R.layout.simple_spinner_item, course);
        //set the array adapter as simple spinner
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //Setting the ArrayAdapter data to the Spinner
        spin.setAdapter(aa);







    }

    @Override
    public void onClick(View v) {
        double f = 0;
        double h = 0;

        //get the index of the selected item in the spinner

            int i = spin.getSelectedItemPosition();
            fees.setText(afees[i]);
            hours.setText(ahours[i]);
            f = new Double(afees[i]);
            h = new Double(ahours[i]);


            if (graduated.isChecked()) {
                if (medical.isChecked()) {
                    f = f + 700;
                    String t = String.format("%.2f", f);
                    totalfees.setText(t);
                    String tt = String.format("%.2f", h);
                    Double ttt = new Double(tt);
                    if (ttt < 21)
                        totalhours.setText(tt);
                    else
                        message.setText("21 hours only");
                } else if (accomodation.isChecked()) {
                    f = f + 1000;
                    String t = String.format("%.2f", f);
                    totalfees.setText(t);
                    String tt = String.format("%.2f", h);
                    Double ttt = new Double(tt);
                    if (ttt < 21)
                        totalhours.setText(tt);
                    else
                        message.setText("21 hours only");
                } else if (medical.isChecked() && accomodation.isChecked()) {
                    f = f + 1000 + 700;
                    String t = String.format("%.2f", f);
                    totalfees.setText(t);
                    String tt = String.format("%.2f", h);
                    Double ttt = new Double(tt);
                    if (ttt < 21)
                        totalhours.setText(tt);
                    else
                        message.setText("21 hours only");
                } else {
                    String t = String.format("%.2f", f);
                    totalfees.setText(t);
                    String tt = String.format("%.2f", h);
                    Double ttt = new Double(tt);
                    if (ttt < 21)
                        totalhours.setText(tt);
                    else
                        message.setText("21 hours only");
                }

            } else if (ungraduated.isChecked()) {
                if (medical.isChecked()) {
                    f = f + 700;
                    String t = String.format("%.2f", f);
                    totalfees.setText(t);
                    String tt = String.format("%.2f", h);
                    Double ttt = new Double(tt);
                    if (ttt < 19)
                        totalhours.setText(tt);
                    else
                        message.setText("19 hours only");
                } else if (accomodation.isChecked()) {
                    f = f + 1000;
                    String t = String.format("%.2f", f);
                    totalfees.setText(t);
                    String tt = String.format("%.2f", h);
                    Double ttt = new Double(tt);
                    if (ttt < 19)
                        totalhours.setText(tt);
                    else
                        message.setText("19 hours only");
                } else if (medical.isChecked() && accomodation.isChecked()) {
                    f = f + 1000 + 700;
                    String t = String.format("%.2f", f);
                    totalfees.setText(t);
                    String tt = String.format("%.2f", h);
                    Double ttt = new Double(tt);
                    if (ttt < 19)
                        totalhours.setText(tt);
                    else
                        message.setText("19 hours only");
                } else {
                    String t = String.format("%.2f", f);
                    totalfees.setText(t);
                    String tt = String.format("%.2f", h);
                    Double ttt = new Double(tt);
                    if (ttt < 19)
                        totalhours.setText(tt);
                    else
                        message.setText("19 hours only");
                }

            }


        }



    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        fees.setText(afees[i]);
        hours.setText(ahours[i]);

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
