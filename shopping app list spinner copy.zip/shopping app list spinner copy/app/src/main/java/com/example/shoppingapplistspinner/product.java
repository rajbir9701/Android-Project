package com.example.shoppingapplistspinner;

public class product {
    private String productName;
    private String productType;
    private double productPrice;
    private int productImage;

    public product(String productName, String productType, double productPrice, int productImage) {
        this.productName = productName;
        this.productType = productType;
        this.productPrice = productPrice;
        this.productImage = productImage;
    }

    public String getProductName() {
        return productName;
    }

    public String getProductType() {
        return productType;
    }

    public double getProductPrice() {
        return productPrice;
    }

    public int getProductImage() {
        return productImage;
    }
}
