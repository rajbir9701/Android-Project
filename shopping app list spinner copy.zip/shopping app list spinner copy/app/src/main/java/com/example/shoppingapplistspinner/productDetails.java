package com.example.shoppingapplistspinner;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class productDetails  extends AppCompatActivity {
    TextView tvname,tvprice;
    ImageView iv;
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.product_detail);
        tvname = findViewById(R.id.txtN);
        tvprice = findViewById(R.id.txtP);
        tvname.setText(MainActivity.name);
        tvprice.setText(String.format("%.2f",MainActivity.price));
        iv = findViewById(R.id.imageView);
        iv.setImageResource(MainActivity.image);
    }

}
